type configEntry ={key: string, value: any}

type configData = configEntry[]

export {
    configEntry,
    configData,
}